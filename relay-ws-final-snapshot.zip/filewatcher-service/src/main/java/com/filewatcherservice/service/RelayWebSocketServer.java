package com.filewatcherservice.service;

import com.filewatchercommon.model.TransferEvent;
import com.filewatchercommon.model.WatchJob;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

import java.net.InetSocketAddress;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Production WebSocket server speaking the "Relay ↔ Monitoring Service"
 * contract (docs/relay-monitoring-ws-contract.md) — the plain-JSON
 * SNAPSHOT / EVENT / SNAPSHOT_REQUEST / COMMAND protocol consumed by the
 * JavaFX app's {@code WebSocketServiceClient}.
 *
 * This drives real {@link WatchJob}s through {@link ServiceManager} /
 * {@link FileWatcherService} — there is no mock/demo data path here.
 *
 * Mapping notes (backend model → contract shape):
 *   - WatchJob.Status {@code WATCHING, TRANSFERRING} → {@code RUNNING};
 *     {@code IDLE, ERROR} → {@code STOPPED}; {@code PAUSED} → {@code DISABLED}.
 *     The contract has no dedicated "error" badge — a failed transfer is
 *     surfaced as its own {@code TRANSFER_FAILED} EVENT (toast/log entry)
 *     rather than flipping the status badge, exactly as the JavaFX
 *     EventDispatcher already expects.
 *   - {@code STARTING}/{@code RESTARTING} are emitted optimistically the
 *     moment a START/RESTART command is accepted, ahead of the real
 *     WATCHING transition that {@link FileWatcherService}'s job-state
 *     listener will report a moment later — this mirrors the contract's
 *     "the client does not assume success just because the command was
 *     sent" guidance while keeping the UI responsive.
 *   - {@code type} is derived from WatchJob.Protocol ("SFTP Watch", "FTP
 *     Watch", ...); {@code destPath}/{@code sourcePath} are rendered as
 *     {@code protocol://host/path} when a remote host is set, or the raw
 *     path for the local side of the transfer.
 *   - {@code credential} has no dedicated field on WatchJob (credentials
 *     aren't referenced by id there — see CredentialStore for the separate
 *     saved-credential list) so the job's own source/dest username is used
 *     as a stand-in.
 *   - {@code filesToday} is WatchJob's cumulative filesTransferred counter
 *     (there's no daily-reset counter in the engine yet).
 *
 * TEST_CONNECTION builds a throwaway {@link CredentialStore.Credential}
 * from the job's own source host/port/user/password and runs the same SSH
 * probe {@link FileWatcherService#testCredential} uses for the Credentials
 * panel, then reports the result as TRANSFER_COMPLETED/TRANSFER_FAILED.
 */
public class RelayWebSocketServer extends WebSocketServer {

    private static final Logger LOG = Logger.getLogger(RelayWebSocketServer.class.getName());
    private static final DateTimeFormatter TS_FMT = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    private final ServiceManager serviceManager;
    private final FileWatcherService watcherService;
    private final Gson gson = new GsonBuilder().create();
    private final ScheduledExecutorService restartExecutor =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "relay-ws-restart");
                t.setDaemon(true);
                return t;
            });

    public RelayWebSocketServer(String host, int port,
                                 ServiceManager serviceManager,
                                 FileWatcherService watcherService) {
        super(new InetSocketAddress(host, port));
        this.serviceManager = serviceManager;
        this.watcherService = watcherService;
        setReuseAddr(true);
        wireListeners();
    }

    /** Convenience overload — binds to localhost. */
    public RelayWebSocketServer(int port, ServiceManager serviceManager, FileWatcherService watcherService) {
        this("localhost", port, serviceManager, watcherService);
    }

    public void shutdown() {
        restartExecutor.shutdownNow();
        try {
            stop();
        } catch (Exception ignored) {
        }
    }

    // ── Wire engine listeners → broadcast as contract EVENTs ─────────────────

    private void wireListeners() {
        watcherService.addJobStateListener(job ->
                broadcastEvent("SERVICE_STATUS_CHANGED", job.getId(), job.getName(), null, null, mapStatus(job)));

        watcherService.addEventListener(this::forwardTransferEvent);
    }

    private void forwardTransferEvent(TransferEvent event) {
        switch (event.getType()) {
            case TRANSFERRED -> broadcastEvent("TRANSFER_COMPLETED",
                    event.getJobId(), event.getJobName(), event.getFileName(), event.getMessage(), null);
            case ERROR -> broadcastEvent("TRANSFER_FAILED",
                    event.getJobId(), event.getJobName(), event.getFileName(), event.getMessage(), null);
            case STARTED -> broadcastEvent("SERVICE_STARTED",
                    event.getJobId(), event.getJobName(), null, null, null);
            case STOPPED -> broadcastEvent("SERVICE_STOPPED",
                    event.getJobId(), event.getJobName(), null, null, null);
            case CONNECTED -> broadcastEvent("HEARTBEAT",
                    event.getJobId(), event.getJobName(), null, null, null);
            case DETECTED, SKIPPED, DISCONNECTED -> {
                // No 1:1 contract event — still logged internally via NotificationService,
                // just not pushed as a distinct UI-facing EVENT to avoid noise.
            }
        }
    }

    // ── WebSocket lifecycle ────────────────────────────────────────────────

    @Override
    public void onOpen(WebSocket conn, ClientHandshake handshake) {
        LOG.info(() -> "Relay client connected: " + conn.getRemoteSocketAddress());
        conn.send(snapshotPayload());
    }

    @Override
    public void onClose(WebSocket conn, int code, String reason, boolean remote) {
        LOG.info(() -> "Relay client disconnected: " + conn.getRemoteSocketAddress());
    }

    @Override
    public void onError(WebSocket conn, Exception ex) {
        LOG.log(Level.WARNING, "Relay WebSocket error", ex);
    }

    @Override
    public void onStart() {
        LOG.info(() -> "Relay WebSocket server (contract) listening on ws://"
                + getAddress().getHostString() + ":" + getAddress().getPort() + "/ws");
    }

    @Override
    public void onMessage(WebSocket conn, String message) {
        JsonObject obj;
        try {
            obj = JsonParser.parseString(message).getAsJsonObject();
        } catch (Exception e) {
            LOG.warning(() -> "Malformed message, ignoring: " + message);
            return;
        }
        String type = obj.has("type") && !obj.get("type").isJsonNull() ? obj.get("type").getAsString() : null;
        if (type == null) return;

        switch (type) {
            case "SNAPSHOT_REQUEST" -> conn.send(snapshotPayload());
            case "COMMAND" -> handleCommand(obj);
            default -> LOG.warning(() -> "Unknown message type from client: " + type);
        }
    }

    // ── Command handling ──────────────────────────────────────────────────

    private void handleCommand(JsonObject obj) {
        String jobId = obj.has("jobId") && !obj.get("jobId").isJsonNull() ? obj.get("jobId").getAsString() : null;
        String command = obj.has("command") && !obj.get("command").isJsonNull() ? obj.get("command").getAsString() : null;
        if (jobId == null || command == null) return;

        WatchJob job = serviceManager.getWatchJob(jobId);
        if (job == null) {
            LOG.warning(() -> "COMMAND '" + command + "' for unknown job id " + jobId);
            return;
        }

        switch (command) {
            case "START" -> {
                broadcastEvent("SERVICE_STATUS_CHANGED", job.getId(), job.getName(), null, null, "STARTING");
                serviceManager.start(jobId); // real outcome broadcast by the job-state listener
            }
            case "STOP" -> serviceManager.stop(jobId); // job-state listener broadcasts STOPPED
            case "RESTART" -> {
                broadcastEvent("SERVICE_STATUS_CHANGED", job.getId(), job.getName(), null, null, "RESTARTING");
                serviceManager.stop(jobId);
                restartExecutor.schedule(() -> serviceManager.start(jobId), 1, TimeUnit.SECONDS);
            }
            case "DELETE" -> {
                serviceManager.removeWatchJob(jobId);
                broadcast(snapshotPayload()); // no dedicated delete EVENT in the contract — refresh everyone
            }
            case "TEST_CONNECTION" -> testConnection(job);
            default -> LOG.warning(() -> "Unknown command: " + command);
        }
    }

    private void testConnection(WatchJob job) {
        CredentialStore.Credential probe = new CredentialStore.Credential();
        probe.setHost(job.getSourceHost());
        probe.setPort(job.getSourcePort());
        probe.setUsername(job.getSourceUser());
        probe.setPassword(job.getSourcePassword());

        String error = watcherService.testCredential(probe);
        if (error == null) {
            broadcastEvent("TRANSFER_COMPLETED", job.getId(), job.getName(), null,
                    "Connection test succeeded", null);
        } else {
            broadcastEvent("TRANSFER_FAILED", job.getId(), job.getName(), null,
                    "Connection test failed: " + error, null);
        }
    }

    // ── Outbound message building ─────────────────────────────────────────

    private String snapshotPayload() {
        JsonObject root = new JsonObject();
        root.addProperty("type", "SNAPSHOT");
        JsonArray jobsArray = new JsonArray();
        for (WatchJob job : serviceManager.getWatchJobs()) {
            jobsArray.add(gson.toJsonTree(toContractJob(job)));
        }
        root.add("jobs", jobsArray);
        return gson.toJson(root);
    }

    private void broadcastEvent(String eventType, String jobId, String jobName, String filename,
                                 String message, String newStatus) {
        JsonObject root = new JsonObject();
        root.addProperty("type", "EVENT");
        root.addProperty("eventType", eventType);
        root.addProperty("jobId", jobId);
        root.addProperty("jobName", jobName);
        root.addProperty("filename", filename);
        root.addProperty("message", message);
        root.addProperty("newStatus", newStatus);
        root.addProperty("timestamp", LocalDateTime.now().format(TS_FMT));
        broadcast(gson.toJson(root));
    }

    // ── WatchJob → contract job shape ─────────────────────────────────────

    private ContractJob toContractJob(WatchJob job) {
        return new ContractJob(
                job.getId(),
                job.getName(),
                describeType(job.getProtocol()),
                describeSide(job.getSourceHost(), job.getSourcePath(), job.getProtocol()),
                describeSide(job.getDestHost(), job.getDestPath(), job.getProtocol()),
                describeInterval(job.getIntervalSeconds()),
                describeCredential(job),
                mapStatus(job),
                (int) job.getFilesTransferred(),
                describeRelativeTime(job.getLastTransfer()),
                describeActivity(job)
        );
    }

    private static String describeType(WatchJob.Protocol protocol) {
        if (protocol == null) return "Watch";
        return switch (protocol) {
            case SFTP -> "SFTP Watch";
            case FTP -> "FTP Watch";
            case SCP -> "SCP Watch";
            case LOCAL -> "Local Watch";
        };
    }

    private static String describeSide(String host, String path, WatchJob.Protocol protocol) {
        String p = path == null ? "" : path;
        if (host == null || host.isBlank() || protocol == WatchJob.Protocol.LOCAL) {
            return p;
        }
        String scheme = protocol.name().toLowerCase();
        return scheme + "://" + host + (p.startsWith("/") ? p : "/" + p);
    }

    private static String describeInterval(int seconds) {
        if (seconds <= 0) return "—";
        if (seconds % 3600 == 0) return (seconds / 3600) + "h";
        if (seconds % 60 == 0) return (seconds / 60) + "m";
        return seconds + "s";
    }

    private static String describeCredential(WatchJob job) {
        if (job.getSourceUser() != null && !job.getSourceUser().isBlank()) return job.getSourceUser();
        if (job.getDestUser() != null && !job.getDestUser().isBlank()) return job.getDestUser();
        return "none";
    }

    private static String describeActivity(WatchJob job) {
        if (job.getStatus() == WatchJob.Status.ERROR && job.getLastError() != null && !job.getLastError().isBlank()) {
            return job.getLastError();
        }
        return switch (job.getStatus()) {
            case WATCHING -> "Polling source directory";
            case TRANSFERRING -> "Transferring file…";
            case PAUSED -> "Paused by operator";
            case ERROR -> "Error";
            case IDLE -> "Idle";
        };
    }

    /** WatchJob's 5 statuses collapse onto the contract's 5 status badges — see class javadoc for the mapping rationale. */
    private static String mapStatus(WatchJob job) {
        return switch (job.getStatus()) {
            case WATCHING, TRANSFERRING -> "RUNNING";
            case PAUSED -> "DISABLED";
            case IDLE, ERROR -> "STOPPED";
        };
    }

    private static String describeRelativeTime(LocalDateTime timestamp) {
        if (timestamp == null) return "—";
        long seconds = Duration.between(timestamp, LocalDateTime.now()).getSeconds();
        if (seconds < 0) seconds = 0;
        if (seconds < 5) return "just now";
        if (seconds < 60) return seconds + "s ago";
        if (seconds < 3600) return (seconds / 60) + "m ago";
        if (seconds < 86400) return (seconds / 3600) + "h ago";
        return (seconds / 86400) + "d ago";
    }

    /** Wire shape for a job row — field names/order match the contract's SNAPSHOT example exactly. */
    private record ContractJob(
            String id,
            String name,
            String type,
            String sourcePath,
            String destPath,
            String pollingInterval,
            String credential,
            String status,
            int filesToday,
            String lastTransfer,
            String currentActivity
    ) {
    }
}
